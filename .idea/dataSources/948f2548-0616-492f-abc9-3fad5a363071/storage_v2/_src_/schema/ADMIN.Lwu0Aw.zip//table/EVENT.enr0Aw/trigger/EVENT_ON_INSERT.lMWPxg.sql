create trigger EVENT_ON_INSERT
    before insert
    on EVENT
    for each row
BEGIN
  SELECT event_sequence.nextval
  INTO :new.id_event
  FROM dual;
END;
/

