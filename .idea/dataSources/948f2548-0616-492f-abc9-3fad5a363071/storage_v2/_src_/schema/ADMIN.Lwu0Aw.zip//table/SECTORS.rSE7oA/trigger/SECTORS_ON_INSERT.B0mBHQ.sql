create trigger SECTORS_ON_INSERT
    before insert
    on SECTORS
    for each row
BEGIN
  SELECT sectors_sequence.nextval
  INTO :new.id_sector
  FROM dual;
END;
/

