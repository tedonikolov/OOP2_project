create trigger SEATS_ON_INSERT
    before insert
    on SEATS
    for each row
BEGIN
  SELECT seats_sequence.nextval
  INTO :new.id_seats
  FROM dual;
END;
/

