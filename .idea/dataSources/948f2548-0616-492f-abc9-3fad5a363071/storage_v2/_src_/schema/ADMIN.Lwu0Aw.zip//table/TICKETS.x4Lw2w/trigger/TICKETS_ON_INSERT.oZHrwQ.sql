create trigger TICKETS_ON_INSERT
    before insert
    on TICKETS
    for each row
BEGIN
  SELECT tickets_sequence.nextval
  INTO :new.id_ticket
  FROM dual;
END;
/

