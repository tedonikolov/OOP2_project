create trigger CLIENT_ON_INSERT
    before insert
    on CLIENT
    for each row
BEGIN
  SELECT client_sequence.nextval
  INTO :new.id_client
  FROM dual;
END;
/

