create trigger AUTONUMBER
    before insert
    on PROFILES
    for each row
begin  
   if inserting then 
      if :NEW."ID_PROFILE" is null then 
         select AUTONUMBER.nextval into :NEW."ID_PROFILE" from dual; 
      end if; 
   end if; 
end;
/

