create trigger ROLES_ON_INSERT
    before insert
    on ROLES
    for each row
BEGIN
  SELECT roles_sequence.nextval
  INTO :new.id_role
  FROM dual;
END;
/

