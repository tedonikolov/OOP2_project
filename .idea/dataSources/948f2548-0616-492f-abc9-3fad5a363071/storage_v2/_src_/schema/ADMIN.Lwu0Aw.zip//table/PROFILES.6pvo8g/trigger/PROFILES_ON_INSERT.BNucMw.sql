create trigger PROFILES_ON_INSERT
    before insert
    on PROFILES
    for each row
BEGIN
  SELECT profiles_sequence.nextval
  INTO :new.id_profile
  FROM dual;
END;
/

